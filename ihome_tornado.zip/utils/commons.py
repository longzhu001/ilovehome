# coding:utf-8

import functools

from utils.session import Session
from utils.response_code import RET


def required_login(fun):
    '''
    自定义装饰器,用来处理登录用户是否存在
    装饰器  首先是一个函数, 然后接受的参数呢,也是一个函数
    经过自己的方法,返回的是一个新的函数
    利用get_current_user 里面获取seesion.data
    怎么难道 get_current_user ,通过 request_handler_obj
    其中request_handler_obj 怎么传过来的, 就是可以利用session
    函数传递参数封装在self里面,传来过来这里,改成了request_handler_obj
    :param fun:request_handler_obj
    :return:wrapper
    '''

    '''
     @functools.wraps(fun)
     # 保证被装饰的函数对象的__name__不变
         Python 中使用装饰器对在运行期对函数进行一些外部功能的扩展。但是在使用过程中，由         于装饰器的加入导致解释器认为函数本身发生了改变，在某些情况下——比如测试时——会导致        一些问题。Python 通过 functool.wraps 为我们解决了这个问题：在编写装饰器时，在          实现前加入 @functools.wraps(func) 可以保证装饰器不会对被装饰函数造成影响。比如         ，在 Flask 中，我们要自己重写 login_required 装饰器，但不想影响被装饰器装饰的           方法
    '''
    @functools.wraps(fun)
    def wrapper(request_handler_obj, *args, **kwargs):
        # 调用get_current_user方法判断用户是否登录
        if not request_handler_obj.get_current_user():
        # session = Session(request_handler_obj)
        # if not session.data:
            request_handler_obj.write(dict(errcode=RET.SESSIONERR, errmsg="用户未登录"))
        else:
            fun(request_handler_obj, *args, **kwargs)
    return wrapper

# @dec
# def add_two(num1, num2):
#     return num1+num2
#
# add_two = dec(add_two)    .__name__ = "add_two"
#
# @dec
# def add_three(num1, num2, num3):
#     return num1+num2+num3
#
# def dec(f):
#     @functools.wraps(f)
#     def wrapper(*args, **kwargs):
#         print("hello")
#         f(*args, **kwargs)
#     return wrapper
#
#
#
# def main(fun):
#     a, b, c = 1, 2, 3
#     if fun.__name__ == "add_two":
#         fun(a, b)
#     elif fun.__name__ == "add_three":
#         fun(a, b, c)























